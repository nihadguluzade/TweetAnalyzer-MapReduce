package time;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class TMapper extends Mapper<Object, Text, Text, IntWritable> {

    private final IntWritable one = new IntWritable(1);

    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
        // Format per tweet is id;user;fullname;url;timestamp;replies;likes;retweets;text
        String tweets = value.toString();
        final String exactDate = context.getConfiguration().get("exact.date", "0");
        if (StringUtils.ordinalIndexOf(tweets,";",8)>-1){

            int startIndex = StringUtils.ordinalIndexOf(tweets,";",4) + 1;
            int finishIndex = StringUtils.ordinalIndexOf(tweets, ";", 5);

            String tweet_date = tweets.substring(startIndex,finishIndex);
            String subdate;

            try {
                subdate = tweet_date.substring(0, 10); // take only date without time
            } catch (StringIndexOutOfBoundsException e) { // for the first line of dataset
                subdate = "-1";
            }

            if (!exactDate.equals("0")) {
                if (exactDate.equals(subdate))
                    context.write(new Text(subdate), one);
            }
            else {
                context.write(new Text(subdate), one);
            }
        }
    }

}



